setwd('C:\\Users\\IT24104275\\Desktop\\IT24104275')

/* Exercise*/
  
# Question 1
  
branch_data <- read.table("Exercise.txt", header = TRUE)
head(branch_data)

# Question 2

str(branch_data)

# Question 3

boxplot(branch_data$sales, 
        main = "Boxplot of Sales",
        ylab = "Sales")

abline(h = median(branch_data$sales), col = "red", lty = 2)

# Question 4

summary(branch_data$advertising)

IQR(branch_data$advertising)

# Question 5

find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR <- Q3 - Q1
  lower <- Q1 - 1.5 * IQR
  upper <- Q3 + 1.5 * IQR
  outliers <- x[x < lower | x > upper]
  return(outliers)
}

find_outliers(branch_data$years)
